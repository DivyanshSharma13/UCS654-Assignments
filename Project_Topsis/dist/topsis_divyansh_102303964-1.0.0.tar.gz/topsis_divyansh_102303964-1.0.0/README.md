# TOPSIS-Divyansh-102303964

A Python package to implement the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS).

## Installation
```bash
pip install Topsis-Divyansh-102303964